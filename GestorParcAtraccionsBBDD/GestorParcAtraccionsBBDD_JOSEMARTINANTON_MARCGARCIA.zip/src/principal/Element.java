package principal;

/**
 *
 * @author Francesca
 */
public interface Element {

    public void modificaElement();

    public void mostraElement();

}
